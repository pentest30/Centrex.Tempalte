﻿using System.ComponentModel.DataAnnotations;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{
    public class Entreprise : DomainAdministration
    {
        [Required]
        [StringLength(50)]
        public string Siret { get; set; }

        [StringLength(100)]
        public string Address { get; set; }
    }

}

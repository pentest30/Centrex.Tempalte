﻿using System.ComponentModel.DataAnnotations;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{
    public class Module
    {
        //public Module()
        //{
        //    Functionalities = new HashSet<Functionality>();
        //}
        [Key]
        public Guid Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Description { get; set; }
        public virtual ICollection<Functionality> Functionalities { get; set; }
    }
}

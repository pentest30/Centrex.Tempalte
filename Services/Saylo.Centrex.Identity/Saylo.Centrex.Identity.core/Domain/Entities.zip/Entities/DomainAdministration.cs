﻿using System.ComponentModel.DataAnnotations;
using Saylo.Centrex.Domain.Entities;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{
    public class DomainAdministration: AggregateRoot<Guid>
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        // Hiérarchie de DomainAdministration
        public Guid? ParentId { get; set; }
        public virtual DomainAdministration Parent { get; set; }
        public virtual ICollection<DomainAdministration> Children { get; set; }
        public virtual ICollection<AdminUser> Users { get; set; }

        // Propriété discriminante
        public TypeEntity TypeEntity { get; set; }


        public virtual ICollection<Functionality> Functionalities { get; set; }
    }
}

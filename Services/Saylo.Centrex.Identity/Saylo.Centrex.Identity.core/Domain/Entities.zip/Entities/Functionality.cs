﻿using System.ComponentModel.DataAnnotations;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{
    public class Functionality
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Code { get; set; }

        [StringLength(255)]
        public string Description { get; set; }
        public ScopeFunctionality Scope { get; set; }
        public TypeFunctionality Type { get; set; }
        public virtual ICollection<DomainAdministration> DomainAdministrations { get; set; }
        public Guid ModuleId { get; set; }
        public virtual Module Module { get; set; }
    }

    public enum ScopeFunctionality
    {
        Entreprise,
        ServiceProvider,
        User
    }

    public enum TypeFunctionality
    {
        Read,
        Create,
        update,
        detete
    }
}

﻿using Microsoft.AspNetCore.Identity;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{

    public class AdminUserRole : IdentityUserRole<Guid>
    {
        public virtual AdminUser User { get; set; }
        public virtual AdminRole Role { get; set; }
       
    }
    
    public class AdminUserClaim : IdentityUserClaim<Guid>
    {
    }

    public class AdminUserToken : IdentityUserToken<Guid>
    {
    }


    public class AdminUserLogin : IdentityUserLogin<Guid>
    {
    }

    public class AdminRoleClaim : IdentityRoleClaim<Guid>
    {
        public virtual AdminRole Role { get; set; }

    }
    public class AdminRole : IdentityRole<Guid>
    {
        public virtual ICollection<AdminUserRole> UserRoles { get; set; }
        public virtual ICollection<AdminRoleClaim> RoleClaims { get; set; }
    }
    public class AdminUser : IdentityUser<Guid>
    {
        public TypeUser TypeUser { get; set; }
        public Guid DomainAdministrationtId { get; set; }
        public virtual  DomainAdministration DomainAdministration { get; set; }
        public virtual ICollection<AdminUserRole> UserRoles { get; set; }

        public bool IsAdmin => TypeUser == TypeUser.Admin;

        
        public IEnumerable<string> GetAutorisedFonctionalite()
        {
            
            var _fonctionalities = IsAdmin ? DomaineFonctionalites : RoleFonctionalites;

            var _claims = UserRoles.SelectMany(userRole => userRole.Role.RoleClaims)
                                  .Select(claim => claim.ClaimType)
                                  .ToList();

            return _fonctionalities.Where(IsAllParentAccess).ToList();

        }

        #region private methods 
        private IEnumerable<string> RoleFonctionalites =>
                                 UserRoles?.SelectMany(userRole => userRole.Role.RoleClaims)
                                .Select(claim => claim.ClaimType)
                                .ToList();

        private IEnumerable<string> DomaineFonctionalites => DomainAdministration.Functionalities.Select(p => p.Code).ToList();

        private bool IsAllParentAccess(string codeFonctionality)
        {
            var domain = DomainAdministration;
            while (domain != null)
            {
                if (!domain.Functionalities.Any(f => f.Code == codeFonctionality))
                    return false;
                domain = domain.Parent;
            }
            return true;
        }
        #endregion

    }
    public enum TypeEntity
    {
        Entreprise,
        ServiceProvider,
        Base
    }

    public enum TypeUser
    {
        Admin,
        User
    }

}

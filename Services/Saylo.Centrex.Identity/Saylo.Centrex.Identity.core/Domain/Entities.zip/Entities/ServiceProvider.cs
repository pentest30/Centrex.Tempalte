﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saylo.Centrex.Identity.Core.Domain.Entities
{
    public class ServiceProvider : DomainAdministration
    {
        [Required]
        [StringLength(50)]
        public string ServiceType { get; set; }

        [StringLength(100)]
        public string ContactEmail { get; set; }
    }
}
